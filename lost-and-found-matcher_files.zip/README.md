# Lost & Found Matching System

A Python-based intelligent matching system that pairs **lost item reports** with **found item reports** based on multiple weighted criteria.

## Problem Statement

A university wants to build a system that automatically suggests possible matches between lost and found items by analyzing:

- Item description similarity
- Color similarity
- Location relevance
- Time relevance

## Approach

The system calculates **four independent similarity scores** (each between `0` and `1`), then combines them using a **weighted average** to produce a final match score.

### Scoring Weights

| Factor      | Weight | Reason                                    |
|-------------|--------|-------------------------------------------|
| Description | 0.4    | Strongest signal of what the item is      |
| Color       | 0.2    | Strong visual identifier                  |
| Location    | 0.2    | Items are usually found near where lost   |
| Time        | 0.2    | Items found close to lost time are likely |

### Algorithms Used

| Component   | Technique                                              |
|-------------|--------------------------------------------------------|
| Description | **Jaccard Similarity** — common words / total words   |
| Color       | Set intersection against a known color dictionary      |
| Location    | Exact match (1.0), partial match (0.7), or none (0.0)  |
| Time        | Time-gap bucketing using `datetime` differences        |

## File Structure

```
lost-and-found/
├── lost_found_matcher.py    # Main implementation
└── README.md                # This file
```

## How to Run

**Requirements:** Python 3.6 or higher (no external libraries needed)

```bash
python lost_found_matcher.py
```

## Sample Output

```
Lost Item #1: black wallet
--------------------------------------------------
  Found #101: black leather wallet
    Total Score: 0.81
    Breakdown  : {'description': 0.67, 'color': 1.0, 'location': 1.0, 'time': 0.7}

Lost Item #2: silver iphone
--------------------------------------------------
  Found #102: silver phone
    Total Score: 0.67
    Breakdown  : {'description': 0.33, 'color': 1.0, 'location': 0.7, 'time': 1.0}
```

## Time Complexity

- **O(L × F)** where `L` = number of lost items and `F` = number of found items.
- For large datasets, pre-filtering by date or location can reduce this significantly.

## Possible Improvements

- **Fuzzy matching** for typos (e.g. `fuzzywuzzy` or `rapidfuzz`)
- **Synonym handling** so "phone" and "mobile" are treated as similar
- **TF-IDF or word embeddings** for richer semantic description matching
- **Database integration** (SQLite / MongoDB) for persistence
- **REST API** layer using Flask or FastAPI
- **Constraint:** Lost time should always be earlier than found time

## Author

Submitted as an interview solution.
